﻿using System.ComponentModel.DataAnnotations;

namespace EventEase_App.Models;

public class Event
{
    public int Id { get; set; }
    [Required(ErrorMessage = "Title is required.")]
    [StringLength(100)]
    public string Title { get; set; } = string.Empty;

    public DateTime Date { get; set; } = DateTime.Today;

    [Required(ErrorMessage = "Location is required.")]
    [StringLength(100)]
    public string Location { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
}
